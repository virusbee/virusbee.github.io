# Obsidian 核心覆盖陷阱

Obsidian 的核心样式表（`app.css`）在 snippet 之前加载，但它的选择器往往更具体，或者直接定义在 `body` 上。以下按症状归类，每条给出触发条件与修法。写 snippet 前扫一遍。

## 一、列表

### 缩进翻倍

**症状**：列表文字比参照页向右偏 16–30px，层级越深偏得越多。

**原因**：核心有 `li { margin-inline-start: 3ch }`，snippet 又给 `ul` 加了 `padding-inline-start`，两者叠加。二级列表还会命中 `ul ul > li` 这类规则再叠一次。

**修法**：

```css
.markdown-rendered li { margin-inline-start: 0; }
.markdown-rendered ul ul > li,
.markdown-rendered ol ol > li,
.markdown-rendered ul ol > li,
.markdown-rendered ol ul > li { margin-inline-start: 0; }
```

只改 `ul { padding }` 不改 `li` 的 margin，永远对不上。

### 每项比参照页高 1px 左右

**症状**：列表总高比预期多，且差值等于条目数。

**原因**：核心 `--list-spacing: 0.075em`，按 16px 算约 1.2px，加在每个 li 上下。

**修法**：`--list-spacing: 0`，或按参照页的实际条目间距重设。

### 圆点颜色 / 大小改不动

**症状**：`::marker { color: ... }` 无效。

**原因**：那个圆点不是 `::marker`，是 `.list-bullet:after` 画的伪元素。

**修法**：

```css
.markdown-rendered ul > li > .list-bullet:after {
  background-color: var(--my-dot-color);
  width: 6px; height: 6px;      /* 实心圆 */
  border-radius: 50%;
}
```

二级改空心只需 `background: transparent; border: 1.5px solid`；三级改方块去掉 `border-radius`。圆点相对文字的水平位置用 `.list-bullet { margin-inline-start: -0.95em }` 微调，具体值靠像素扫描定。

### 有序列表序号对不上

**症状**：`1.` / `a.` / `i.` 的层级方案无法通过 `list-style-type` 精确控制间距，序号的列宽随位数变化。

**原因**：`::marker` 与文字的间距由 Chromium 决定，CSS 无法调整。

**修法**：`list-style: none` + 计数器 + 绝对定位：

```css
.markdown-rendered ol { list-style: none; counter-reset: item; }
.markdown-rendered ol > li { position: relative; padding-inline-start: 24px; }
.markdown-rendered ol > li::before {
  counter-increment: item;
  content: counter(item) ".";
  position: absolute; inset-inline-start: 0; width: 18px;
}
```

多级用 `counter(item, lower-alpha)` / `lower-roman`，并为每级单独 `counter-reset`。`<ol start="10">` 需要读 `start` 属性，纯 CSS 计数器不认，只能在渲染时由 Markdown 源决定。

### 任务清单复选框

**症状**：复选框位置偏、尺寸不对，暗色下几乎看不见。

**原因**：Obsidian 用原生 `<input type="checkbox">`，外观由 `color-scheme` 决定；`.task-list-item` 自带 `padding-inline-start`。

**修法**：

```css
.markdown-rendered .task-list-item { padding-inline-start: 0; }
.markdown-rendered input[type="checkbox"] {
  appearance: none; width: 13px; height: 13px;
  border: 1px solid #b8bfc6; border-radius: 2px;
  position: relative; top: 1px;   /* 与首行基线对齐 */
  color-scheme: light;            /* 暗色下保持可见，或自绘勾 */
}
```

自绘勾用 `input:checked::after { content: "√" }`，此时必须 `color-scheme: light` 之外的完整重置。

## 二、排版节奏

### 标题上边距被吃掉

**症状**：`h1 { margin-top: 30px }` 写了但无效，或只对部分标题无效。

**原因**：核心有 `p + h1` 这类更高优先级的相邻选择器，或者 `--heading-spacing` 变量参与计算。

**修法**：`--h1-spacing-before` / `--h1-spacing-after` 系列变量逐级注入，或在规则上加 `.markdown-rendered` 前缀提高优先级。不要用 `!important` 起手，先用变量。

### 段落间距不一致

**原因**：核心 `--p-spacing: 1rem`，且 `p { margin-block: 0 }` 与某些主题的 `p + p { margin-top }` 混用。

**修法**：明确选择一种模型，要么 margin（`--p-spacing` 归零 + 自己写 `margin-block`），要么 padding（`margin: 0; padding-block: 8px`）。参照页用哪种就跟哪种，混用必然差几像素。

### 粗体比预期粗

**原因**：核心 `--bold-modifier: 200`，粗体字重是 `calc(400 + modifier)` = 600，不是 700。

**修法**：`--bold-modifier: 300`（得 700）或显式 `strong { font-weight: 700 }`。

### 行内 code / kbd 让整行变矮

**症状**：含行内代码的段落之后，所有块整体上移 1–3px。

**原因**：核心按字号比例算行高（如 14px × 1.625 = 22.75px），比正文行高小，行盒被压矮。

**修法**：行内 code / kbd 的行高写绝对值：

```css
.markdown-rendered :is(code, kbd) { line-height: 26px; vertical-align: middle; }
```

这个坑极隐蔽：偏差是全局的、恒定的（例如整页 2.3px），很容易误判成容器 padding 问题。

### 字号变量不生效

**原因**：社区主题在 `.theme-dark` 上重定义了 `--h1-size`、`--code-*`，选择器权重 0,1,1 高于 `body`。

**修法**：变量定义挂在 `body, body.theme-dark, body.theme-light` 上，三条选择器一起写。规则本身再用 `.markdown-rendered h1 { font-size: 24px }` 钉死，不完全依赖变量。

## 三、代码块

### 代码块多一条边 / 双层背景

**症状**：阅读视图里代码块有双边框，或实时预览里背景色只覆盖部分行。

**原因**：实时预览由 `HyperMD-codeblock-bg` 这一层画背景与边框，snippet 又在 `.cm-line` 上画一次。

**修法**：背景交给那一层，行上只补首尾圆角与 padding。

### 代码块字体、字号不同

**原因**：核心用 `--font-monospace` 与 `--code-size`，与正文继承链分离。

**修法**：显式设置 `pre, pre code { font-family: ...; font-size: 14.4px }`，并把 `--code-size` 一起改，否则实时预览与阅读视图不一致。

### 代码高亮颜色被覆盖

**原因**：`--code-keyword`、`--code-string` 等变量由社区主题在 `.theme-dark` 上重定义。

**修法**：同"字号变量不生效"，把 `--code-*` 全部写在 `body.theme-dark` 上。

## 四、表格

### 单元格文字贴顶

**原因**：`--table-cell-vertical-alignment: top` 是 Obsidian 默认值，浏览器默认是 `middle`。

**修法**：`th, td { vertical-align: middle }`。

### 边框双线 / 白缝 / 斑马纹断裂

**原因**：`border-collapse: separate` 加 `border-spacing` 时，每格自带边框，相邻两格之间出现"双线 + 缝"；斑马纹挂在 `td` 上会被竖缝切断。

**修法**：

```css
.markdown-rendered table { border-collapse: collapse; border-spacing: 0; }
.markdown-rendered tbody tr:nth-child(2n) { background: #f8f8f8; }  /* 挂在 tr 上 */
```

若要还原参照页的双线效果，背景必须挂回 `td`，并接受条纹被切断的事实。

### 表格宽度溢出 / 出现横向滚动条

**原因**：`.table-wrapper` 带 `overflow: auto`，且 `min-width` 累加超过版心。

**修法**：降低单元格 `min-width`，或给 `.table-wrapper { overflow-x: visible }`（仅测试用）。

## 五、其他块

### 图片上下多出 8px

**原因**：图片在 `<p>` 里，继承了段落 padding。

**修法**：`p:has(> img:only-child) { padding-block: 0; }`。

### 引用左边框位置不对

**原因**：核心用 `border-inline-start` 加 `padding-inline-start`，与参照页的 `border-left` 语义相同但书写方向不同（RTL 会翻转）。

**修法**：跟参照页保持同一侧，用 `border-inline-start` 更稳。

### 链接颜色 / 下划线不受控

**原因**：核心区分 `--link-color`（内部）与 `--link-external-color`（外部），下划线由 `--link-decoration` 控制。

**修法**：三条一起设，否则内链外链长得不一样。

### 分隔线消失

**原因**：核心 `hr` 是 `height: 0; border-top: 1px`，某些主题改成 `border: none` 后就不见了。

**修法**：显式给 `border: 0; border-top: 1px solid ...; height: 0`。

## 六、字体渲染

### 同样字体却更粗

**原因**：页面级 `-webkit-font-smoothing: antialiased` 是继承属性，参照页有、Obsidian 没有。灰度抗锯齿比次像素渲染细 12%–15%。

**修法**：

```css
.markdown-rendered,
.markdown-source-view.mod-cm6,
.markdown-source-view.mod-cm6 .cm-content {
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
}
```

### 中文字重只有三档

**事实**：Chrome 里 PingFang SC 的 600 直接映射到 Bold，700 与 600 渲染完全一致（墨量相同）。可用档位只有 700 / 500 / 400。

**含义**：要"细一档"就写 500，不要写 600。

### 指定字体没生效

**原因**：字体不在本机，一路回落到 serif/黑体；或 `unicode-range` 缺失导致中文落到别的字体。

**修法**：用 CDP `CSS.getPlatformFontsForNode` 确认实际命中的字面，不要靠猜。需要固定字体时把 woff2 base64 内嵌，并保留 `unicode-range`。

## 七、作用域与优先级

- 阅读视图统一用 `.markdown-rendered` 前缀；实时预览统一用 `.markdown-source-view.mod-cm6` 前缀。两套都要写。
- 变量定义放 `body, body.theme-dark, body.theme-light`，不要只写 `body`。
- 尽量不用 `!important`；它会让社区主题的切换彻底失效。优先靠变量和选择器权重。
- 版心宽度用 `--file-line-width`，sizer 的 `padding-inline` 会被核心规则重新加上，测试页里要显式归零。

## snippet 骨架

```css
/* 来源：<站点/文件> | 日期：<YYYY-MM-DD> | 实测：正文 16px/1.8、版心 670、段距 8+8 */
body, body.theme-dark, body.theme-light {
  --x-font: Optima, "PingFang SC", serif;
  --x-font-mono: Consolas, Menlo, monospace;
  --x-text: #000;
  --x-bg: #fff;
  --x-line-px: 28.8px;        /* 行内 code/kbd 用的绝对行高 */
  --h1-size: 24px; --h1-weight: 700; --h1-line-height: 1.5;
  /* … h2–h6 */
}

.markdown-rendered { /* 正文 */ }
.markdown-rendered h1 { }
.markdown-rendered ul > li > .list-bullet:after { }
.markdown-rendered table { }
.markdown-rendered pre { }

.markdown-source-view.mod-cm6 { /* 实时预览同名规则 */ }
.markdown-source-view.mod-cm6 .cm-line.HyperMD-header { }
.markdown-source-view.mod-cm6 .cm-table-widget table { }

body.theme-dark { /* 只换色 */ }
```
