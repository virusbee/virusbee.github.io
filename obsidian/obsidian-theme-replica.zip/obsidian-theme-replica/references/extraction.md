# 取参照样式

复刻的第一步是把"参照"变成可读的 CSS 与可跑的 HTML。三条路径，按可得性选。

## 路径 A：本地 CSS 文件

适用于 Typora、VS Code、Zed 这类把主题放在安装目录里的编辑器。

```bash
# Typora
ls /Applications/Typora.app/Contents/Resources/TypeMark/style/
#  typically: base.css  github.css  night.css  pixyll.css ...

# VS Code
ls ~/.vscode/extensions/<theme>/themes/
```

读的时候注意三件事：

1. **主文件 + base**：Typora 的主题只写差异，布局与变量在 `base.css`。两层叠加后才是最终样式。
2. **字体**：`@font-face` 里的 `src: url(...woff2)` 与 `unicode-range` 必须一起搬，否则中文会落到别的字体。需要固定字形时把 woff2 转 base64 内嵌。
3. **变量**：`--typora-*` 这类自定义属性在 `:root` 或 `html` 上，先全部抄下来再改。

这类主题不需要量测就能拿到大部分值，但**仍然要做逐块比对**：Typora 的排版依赖它自己的行盒计算，Obsidian 的不一样。

## 路径 B：公开页面

适用于任何能直接打开的渲染页。

```bash
"/Applications/Google Chrome.app/Contents/MacOS/Google Chrome" \
  --headless=new --remote-debugging-port=9300 \
  --user-data-dir=/tmp/prof-x --no-sandbox --disable-gpu \
  --disable-dev-shm-usage --allow-file-access-from-files \
  --hide-scrollbars about:blank
```

然后用 `scripts/measure.js --port 9300 --eval "<js>"` 探查，或写一段 CDP 脚本。要取的东西固定是这些：

```js
// 每个块的最终样式
[...document.querySelectorAll('#nice > *')].map(el => {
  const s = getComputedStyle(el), r = el.getBoundingClientRect();
  return { tag: el.tagName, cls: el.className, y: r.y, h: r.height,
           fs: s.fontSize, lh: s.lineHeight, fw: s.fontWeight,
           mt: s.marginTop, mb: s.marginBottom, pt: s.paddingTop, pb: s.paddingBottom,
           color: s.color, bg: s.backgroundColor };
});
```

两个常见障碍：

- **虚拟滚动**（飞书、语雀）：不滚到视口内根本不渲染。必须一边滚一边采，或直接拿文档的完整 CSS。
- **跨域样式表**：`document.styleSheets[].cssRules` 会抛 SecurityError。用 `curl` 把 CSS 文件下下来，比在页面里绕更快。

```bash
curl -s "https://<host>/<hash>.css" -o /tmp/site-full.css
```

## 路径 C：需要登录的编辑器（mdnice、公众号排版）

这类站点的主题是 CSSOM 注入的，`document.styleSheets` 里找不到，必须走 CDP。

1. **先让用户登录**。起一个可见的 Chrome（非 headless），用固定 `--user-data-dir` 保留登录态，让用户扫码。
2. **让用户或脚本切到目标主题**。UI 路径要问清楚（例如 mdnice 是「主题 → 我的 → 自定义主题1 → 使用」）。
3. **反查命中的样式表**。从一个已知元素出发，取它命中的所有规则，再从规则拿到 `styleSheetId`，最后导出整张表：

```js
// 1) 取 nodeId
const { root } = await send('DOM.getDocument');
const { nodeId } = await send('DOM.querySelector', { nodeId: root.nodeId, selector: '#nice h1' });

// 2) 取命中样式
const m = await send('CSS.getMatchedStylesForNode', { nodeId });
// m.matchedCSSRules[].rule.styleSheetId + .rule.selectorList.text

// 3) 导出整张表
const sheet = await send('CSS.getStyleSheetText', { styleSheetId });
```

4. **导出的是整张表，不是 diff**。这类编辑器的"自定义主题"通常只存几条覆盖规则，其余来自基底主题。只抄 diff 会丢掉 90% 的样式。

5. **顺带导出文章 HTML**。`#nice` 的 `outerHTML` 决定了 DOM 结构，而结构本身是样式的一部分：

```
mdnice:   <h1><span class="prefix"></span><span class="content">标题</span><span class="suffix"></span></h1>
          <li><section>条目</section></li>
```

标题的字号规则挂在 `.content` 上，直接写 `<h1>文字</h1>` 会退化成浏览器默认值。把这份 HTML 当参照页的模板，比任何预设都准。

6. **检查 body 级规则**。这一步最容易漏：

```js
getComputedStyle(document.body).webkitFontSmoothing   // "antialiased" ?
getComputedStyle(document.body).fontFamily
getComputedStyle(document.body).fontSize
```

页面级的 `-webkit-font-smoothing: antialiased` 不在主题作用域里，但会让笔画细 12%–15%，是"字重不对"最常见的原因。取不到时用 `--eval` 逐条读，不要假设默认值。

## 字体取证

怀疑字体不对时，用平台字体接口确认实际命中的字面：

```js
const f = await send('CSS.getPlatformFontsForNode', { nodeId });
// f.fonts: [{ familyName: "Optima", glyphCount: 20 }, { familyName: "PingFangSC-Regular", glyphCount: 11 }]
```

`glyphCount` 能告诉你哪段文字落到了哪个字体。中英混排时两组字体是正常的，全部落到 `Times` / `Songti` 就说明字体栈失效了。

`measure.js --probe` 会把前 40 个块的平台字体一起写进 JSON，省掉手写这段。

## 取样式清单

无论哪条路径，最后要凑齐这组值，缺一项都可能造成 1px 级别的偏差：

- 版心宽度、左右内边距
- 正文字号、行高、字重、颜色、字体栈
- 段落的 margin / padding 模型（二者选一）
- 六级标题的字号、字重、行高、上下边距
- 列表每层的缩进、符号形状与颜色、条目间距
- 引用的边框粗细/颜色、内边距、内部字号
- 表格边框、单元格 padding、表头与斑马纹底色、垂直对齐
- 行内代码与代码块的字号、行高、背景、圆角、padding
- 链接颜色与下划线、分隔线、图片上下间距
- body 级渲染设置（font-smoothing、text-rendering）
- 组件级盒子样式：代码块的背景、padding、圆角、阴影，图片容器、表格外框

最后一条最容易漏。网页的代码块盒子常常由应用层 CSS 或组件库给的，不在"主题"那份样式表里：mdnice 的主题 CSS 只有 `pre.custom { margin: 10px 0; padding: 0 }` 和 `pre.custom code { font-size: 12px }`，真正的 `#282C34` 背景与 15/16px 内边距来自编辑器本身。只导主题 CSS 建参照页，代码块会比线上矮 50px 左右，然后你会去改 snippet，越改越错。判断方法：参照页里这个盒子的 `backgroundColor` 是透明、`padding` 是 0，而线上截图明明有底色和内边距，就是漏了应用层样式，要去 `getComputedStyle` 里补，别信主题文件。
