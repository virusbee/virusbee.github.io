# 量测与比对方法

复刻的可信度来自"能复现同一个像素"。这份文档说明量什么、怎么读结果、遇到偏差怎么定位。

## 坐标系与偏移

所有坐标都是 CSS px，来自 `getBoundingClientRect()`。截图按 `deviceScaleFactor: 2` 输出，所以截图里的像素是坐标的两倍；倍率记录在 JSON 的 `doc.scale`。

两侧的起点天然不同：参照页从容器顶部开始，Obsidian 页面里还有 `.markdown-preview-view` 的内边距与顶栏。所以比对时用**首块对齐**：

```
offset = obs.firstBlock.y - ref.firstBlock.y
dy(第 n 块) = obs.y - offset - ref.y
```

`compare.py --offset auto` 就是这么算的。首块本身永远 dy = 0，它是基准。

**首块要选有内容的第一块**，不要选被空的 div 或注释节点占位的元素。若首块异常，改用 `--offset <数值>` 手动指定。

## 读 compare.py 的输出

```
offset used: 44.00 px (auto)
blocks: 55 matched, 0 unmatched
worst dy: 0.00 px at '一级标题'
clean: 55 / 55
```

四行各自的意义：

- **offset**：整体位移。这里是 44px，属于容器内边距差，不是错误。
- **matched**：按文本对齐的块数。出现 unmatched 说明内容没渲染完或 DOM 结构差异过大。
- **worst dy**：最大偏差。超过 0.6px 就要查。
- **clean**：完全干净的块数。目标 100%。

逐块表里 `DY` 是纵向偏差，`DH` 是块高偏差。**DH 往往比 DY 更有信息量**：块高不对说明字号、行高或内边距错了，而 DY 可能只是前面某个 DH 的累积。

先修最靠前的异常块。后面的 dy 常常随之归零。

## 容差

| 场景 | 容差 | 说明 |
|---|---|---|
| 1:1 复刻 | 0.5–0.6px | 亚像素舍入造成的固有误差 |
| 目检像即可 | 2px | 块高仍需准确，位移可放宽 |
| 文字宽度 | 1% | 字体或 letter-spacing 差异会累积到换行 |

偏差恰好是 0.5 的整数倍时，通常是某处 `padding` / `margin` 被按比例缩放，或 `line-height` 用了相对值。

## 定位偏差的三种手段

### 1. 块级二分

把 `compare.py` 的表按 tag 过滤，看偏差从哪一类块开始出现。标题开始漂 = 标题的 margin 或 line-height；列表开始漂 = 缩进或符号行盒；代码块开始漂 = `pre` 的行高或 padding。

### 2. 像素扫描

块级坐标只能告诉你"这一块差了 3px"，告诉不了"是左边框还是 padding"。裁一块图放大，扫连续暗像素的行/列：

```python
from PIL import Image
im = Image.open('/tmp/obs.png').convert('RGB')
px = im.load(); W, H = im.size
# 找竖直边框：某一行上连续偏暗的 x 区间
y = 300
runs = [(x, px[x, y]) for x in range(W) if sum(px[x, y]) / 3 < 235]
```

圆点位置、复选框基线、边框粗细这类问题只能这样定。

### 3. 规则二分

改 CSS 之前先确认是哪条规则在起作用。在测试页的 `--extra-css` 里追加一条覆盖，看数值是否变化；变化则说明原规则被盖住了。这比读 `app.css` 快得多。

## 墨量比对

`--ink` 统计文本块里的暗像素数与总暗度（`Σ(255 - 亮度)`），用于判断字重与抗锯齿是否一致。

- 正常：±5%
- 明显偏粗：+10% 以上 → 检查 `-webkit-font-smoothing` 与 `--bold-modifier`
- 明显偏细：−10% 以上 → 检查是否误加了 `font-weight: 300`，或字体落到了细体

两个前提：

1. **只在文字块上有意义**。代码块、表格的深色背景会盖过文字墨量，所以脚本只统计 `h1-h6 / p / li / td / th / blockquote`。
2. **必须逐块裁剪各自的坐标**。全局 offset 只用于比较位置，不能用于裁图，否则 dy 累积后裁到空白区，会得到"墨量 −100%"这种假数据。

历史参考值：同一套字体、同样内容，灰度抗锯齿相对次像素渲染约 −14%。如果整页墨量落在这个区间，字重就是对的。

## 已知假象

### 参照页不完整

参照页只注入了你拿到的 CSS。若主题依赖另一张样式表（编辑器基底样式、站点全局样式），参照页会缺规则。

识别信号：参照页的列表项高度全部等于一行正文（例如统一 24px），而真实页面明显更松。此时 diff 会把"参照页缺规则"误报成"snippet 多了间距"。

处理：先拿参照页截图和真实页面截图对一遍，确认一致后再用它当基准。

### 截图全白

`Page.captureScreenshot` 带 `clip` 且高度超过视口时，软件渲染下常返回纯白图，而几何数据完全正常。`measure.js` 的做法是把视口高度撑到内容高度再截，不做 clip。

另一个更隐蔽的原因：**app.css 用 `height: 100vh` + paint containment 布局外壳**。只把 `.app-container` 改成 `height: auto`，容器高度会塌成 0，所有像素被裁掉，但 `getBoundingClientRect()` 依旧返回正确坐标，于是"量得出、截不出"。

`obs_harness.py` 的处理是把整组外壳（`.app-container` / `.workspace*` / `.view-content` / `.markdown-reading-view` / `.cm-editor` / `.cm-scroller`）**同时**改成 `height: auto` + `overflow: visible` + `position: static` + `display: block`。四条缺一不可：只加 `height: auto` 或只加 `display: block` 都会得到空白图。不要"优化"成只改一条。

### 字体加载

截图前必须等 `document.fonts.status === 'loaded'`。`measure.js` 已经轮询，自写脚本时容易漏，表现为首屏文字宽度差几像素。

### 内联 SVG 与背景图

背景图（窗口点、图标）在截图中存在，但 `getComputedStyle` 只给 `url("data:...")`，比对时要单独人眼确认位置。`background-position` 差 10px 在表格里非常显眼。

## 一轮完整的闭环

```bash
# 1 生成两侧页面
python3 scripts/obs_harness.py --mode ref ... --out /tmp/ref.html
python3 scripts/obs_harness.py --mode obs ... --out /tmp/obs.html

# 2 量测 + 截图
node scripts/measure.js file:///tmp/ref.html --out /tmp/ref.json --shot /tmp/ref.png --launch --deep
node scripts/measure.js file:///tmp/obs.html --out /tmp/obs.json --shot /tmp/obs.png --launch --deep

# 3 比对（退出码非 0 表示仍有偏差）
python3 scripts/compare.py /tmp/ref.json /tmp/obs.json --tol 0.6 \
    --ink --shot-ref /tmp/ref.png --shot-obs /tmp/obs.png --img /tmp/cmp.png

# 4 改 snippet，回到 2
```

一次闭环通常是十几次工具调用。偏差集中在某一类块时，只重建那一部分内容的测试页能显著提速。
