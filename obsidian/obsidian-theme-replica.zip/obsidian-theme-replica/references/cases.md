# 四套已完成主题的参照数据

这四套都已交付并通过逐块对齐。数据可直接当新主题的对照基准，也是"某种排版长什么样"的实例库。

## 一、飞书文档（在线页面，虚拟滚动）

取样式：CDP 边滚边采 + `curl` 下载跨域的 `full.css`。猜测起步失败过一次（按设计规范推的 15px/1.75/版心 900 全错），改用真实文档链接后重做。

| 项 | 值 |
|---|---|
| 正文 | 16px / 26px，色 #1F2329 |
| 版心 | 820px |
| 标题字重 | 500（六级统一） |
| 正文左边界 | 130，列表文字 154，序号 133.5–144.5 |
| 代码字体 | SourceCodeProMac，本机缺失 |

具体坑：

- 虚拟滚动：不滚到视口内的内容不渲染，必须滚动采样。
- 列表缩进叠加：核心 `li { margin-inline-start: 3ch }` + 自己加的 `padding-inline-start`。
- 圆点不是 `::marker`，是 `.list-bullet:after`。
- 有序列表三级方案 `1.` / `a.` / `i.`，`::marker` 间距不可控，改 `counter(list-item, lower-alpha)` + 绝对定位。
- 代码字体缺失 → 从 Google Fonts 取 latin 子集，11.6KB woff2 base64 内嵌。
- 变量共用：`--feishu-list-indent` 同时管无序列表、有序列表、待办，改一处坏三处。

返工五轮：缩进、垂直节奏、二三级符号形状、嵌套参考线、代码字体。

## 二、Typora Github（本地 CSS）

取样式：直接读 `github.css` + `base.css`，无头 Chrome 渲染同内容后取计算样式。

| 项 | 值 |
|---|---|
| 正文 | 16px / 1.625，色 #333 |
| 版心 | 800px，段距 12.8px |
| 标题 | 36 / 28 / 24 / 20 / 16 / 16，全 700，H1/H2 带 1px #eee 下边框 |
| 列表 | 每层 30px；实心 6px、空心 5.5px、方块 5px；`margin-inline-start: -0.95em` |
| 引用 | 4px #dfe2e5，padding 0 15px |
| 表格 | 1px #dfe2e5，单元格 6px 13px，表头与偶数行 #f8f8f8 |
| 行内代码 | 0.9em，底 #f3f4f4，1px #e7eaed，3px 圆角 |
| 代码块 | 14.4px，#f8f8f8，3px 圆角 |
| 链接 | #4183C4，带下划线 |
| 体积 | 990 行 / 127KB（Open Sans 四个字形内嵌） |

具体坑：

- `--p-spacing` 与 `--heading-spacing` 必须逐级注入，否则 `p + h1` 会吃掉标题上边距。
- `--bold-modifier` 不清零，粗体变 `calc(400 + 200)` = 600。
- 圆点偏右 3px，像素扫描定出"圆心距文字 15px"，改用 `-0.95em`。
- 暗色下原生复选框几乎不可见 → `color-scheme: light`。
- 实时预览代码块多一条 2px 边：`HyperMD-codeblock-bg` 已画过一次。

## 三、Typora Night（本地 CSS）

取样式同上。原以为是换色，实际是另一套排版。

| 项 | 值 |
|---|---|
| 纸面 / 正文 | #363B40 / #b8bfc6，16px / 26px |
| 版心 | 914px，段落 mb 24px |
| 标题 | 40 / 26.08 / 18.72 / 17.92 / 15.52 / 14.88；只有 H2/H3/H5 是 700 |
| H1 | 字距 −1.5px，上边距 80px；H2–H6 上边距 0 |
| 引用 | 2px #474d54，padding-left 30px，文字 #9DA2A6 |
| 表格 | 1px #474d54，单元格 5px 10px，无底色 |
| 行内代码 | 14px，底 rgba(0,0,0,.05)，无边框无圆角 |
| 代码块 | #333，padding 10/10/10/30，行高 26px |
| 高亮 | keyword #C88FD0，string #D26B6B，comment #DA924A，function #8d8df0，number #84B6CB |
| 体积 | 947 行 / 25KB（无内嵌字体） |

具体坑：

- **整页偏移 2.3px**：行内 `code` 按 14 × 1.625 = 22.75px 算行高，`kbd` 23.4px，都比正文 26px 矮，行盒被压。改成绝对 `line-height: 26px` 并保留 `vertical-align: middle` 归零。
- `--code-*` 被社区主题在 `.theme-dark` 上重定义，选择器要提到 `body.theme-dark`。
- 任务清单需 `.task-list{padding-left:0}` + 自绘 14×14 方框，勾用 `√`。

这一版没有字体文件，体积小，但耗时超过 Github 版：规则越偏离默认值，猜的空间越大。

## 四、mdnice 自定义主题1（登录态编辑器，CSSOM）

取样式：扫码登录 → 点「主题 → 我的 → 自定义主题1 → 使用」→ CDP `CSS.getMatchedStylesForNode` 从 `#nice h1` 反查 → `getStyleSheetText` 导出整张表，16922 字符。

自定义主题本身只有五条 diff（H2 上边距 90px、H3 下边距 0、`ul` 上移 5、`ol` 上移 10、行内代码粉色），其余全部来自基底主题，所以必须导整张表。

| 项 | 值 |
|---|---|
| 正文 | 16px / 1.8 #000；段落 `margin:0` + `padding:8px 0` |
| 标题 | 24 / 22 / 20 / 18 / 16 / 14，全 700，行高 1.5；H2 上边距 90px |
| 列表 | 每层 25px，全 disc，条目间距 5px，`ul` 上 −5 / `ol` 上 −10 |
| 引用 | 3px rgba(0,0,0,.4) + 5% 黑底，padding 10/10/10/20 |
| 表格 | 1px rgba(204,204,204,.4)，表头 #F0F0F0，偶数行 #F8F8F8，单元格 5px 10px |
| 行内代码 | 14px #FC5FA2，底 rgba(27,31,35,.05)，padding 2px 4px，4px 圆角 |
| 代码块 | #282C34 + 三窗口点 SVG（`background-position: 10px 10px`，`background-size: 40px auto`），12px / 26px，padding 15/16/16 |
| 链接 | #1E6BB8，700，无下划线 |
| 字体 | Optima + 苹方，页面级 `antialiased` |
| 体积 | 712 行 / 19.9KB |

具体坑：

- 参照页 DOM 必须带 `<span class="content">`，字号规则挂在这个 span 上。
- 表格原本是 `separate` + `border-spacing: 2px`，逐块坐标全对，但视觉上是"碎盒子"。改成 `collapse` 后每行少 1px，条纹改挂 `tr`。这是一次"数据对、观感错"的典型，取舍要交回用户。
- 嵌套列表每层变 50px：核心缩进 + snippet 缩进叠加，四条 `ul ul > li` 归零。
- 图片段落多 8px：`p:has(> img:only-child){padding-block:0}`。
- 窗口点偏右 10px：`background-position` 从 20px 改 10px。
- 字体"不够纤细"查到最后是 body 级 `antialiased`，墨量 48054 → 41136（−14.4%）。
- 标题"还是粗"：`antialiased` 是继承属性，标题早就吃到了，但 700 的大字号下灰度与次像素只差 9%。真正的开关是字重，而 PingFang 的 600 直接映射到 Bold（700 与 600 墨量同为 2157 点），可选档只有 700 / 500 / 400。最终落在 500，比原主题更细，这是按用户偏好做的取舍。

## 共性结论

1. **字重问题八成不是字体栈**。先查 `-webkit-font-smoothing`，再查 `--bold-modifier`，最后才看 font-family。
2. **整页恒定偏移**（如 2.3px）几乎都是行内元素的行盒高度造成的，不是容器 padding。
3. **元数据不可信**。设计规范写 15px，真实页面 16px；编辑器导出的"自定义主题"只有五条规则。
4. **几何全对仍可能难看**。表格双线、代码块阴影都属于这一类，交付时给开关。
5. **每套主题的坑位置不同，但类型固定**：变量被覆盖、缩进叠加、行盒计算、伪元素取代 `::marker`、字体缺失。四套加起来覆盖了 20 余种，见 `obsidian-overrides.md`。
