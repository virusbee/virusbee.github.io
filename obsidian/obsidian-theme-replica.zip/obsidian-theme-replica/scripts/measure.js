#!/usr/bin/env node
/**
 * Measure a rendered page through CDP: per-block geometry, computed typography,
 * optional full-page screenshot, optional font/probe data.
 *
 *   node measure.js <url-or-file> --out geo.json [--shot page.png]
 *      [--w 760] [--h 900] [--scale 2] [--rootsel SEL] [--deep]
 *      [--probe] [--launch] [--port 9300]
 *
 * --launch  starts its own headless Chrome (temp profile) and kills it on exit.
 * Without --launch it attaches to an already-running Chrome on --port / $CDP_PORT.
 *
 * Usage as a library: require('./measure.js').run(opts)
 */

'use strict';

const fs = require('fs');
const os = require('os');
const path = require('path');
const { spawn } = require('child_process');
const net = require('net');

const CHROME_CANDIDATES = [
  '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',
  '/Applications/Chromium.app/Contents/MacOS/Chromium',
  '/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge',
  '/usr/bin/google-chrome',
  '/usr/bin/chromium',
  '/usr/bin/chromium-browser',
  'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe',
];

function findChrome() {
  for (const p of CHROME_CANDIDATES) if (fs.existsSync(p)) return p;
  throw new Error('Chrome not found. Pass --chrome <path>.');
}

function freePort() {
  return new Promise((resolve, reject) => {
    const srv = net.createServer();
    srv.on('error', reject);
    srv.listen(0, '127.0.0.1', () => {
      const p = srv.address().port;
      srv.close(() => resolve(p));
    });
  });
}

const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

async function waitJson(port, timeoutMs = 15000) {
  const t0 = Date.now();
  while (Date.now() - t0 < timeoutMs) {
    try {
      const r = await fetch(`http://127.0.0.1:${port}/json/version`);
      if (r.ok) return await r.json();
    } catch (_) {}
    await sleep(150);
  }
  throw new Error('Chrome debug port did not open on ' + port);
}

class CDP {
  constructor(ws) {
    this.ws = ws;
    this.id = 0;
    this.pending = new Map();
    ws.addEventListener('message', (ev) => {
      const m = JSON.parse(ev.data);
      if (m.id && this.pending.has(m.id)) {
        const { res, rej } = this.pending.get(m.id);
        this.pending.delete(m.id);
        m.error ? rej(new Error(JSON.stringify(m.error))) : res(m.result);
      }
    });
  }
  send(method, params = {}) {
    return new Promise((res, rej) => {
      const id = ++this.id;
      this.pending.set(id, { res, rej });
      this.ws.send(JSON.stringify({ id, method, params }));
    });
  }
  async eval(expression) {
    const r = await this.send('Runtime.evaluate', {
      expression,
      returnByValue: true,
      awaitPromise: true,
    });
    if (r.exceptionDetails) throw new Error(r.exceptionDetails.text + ' ' + (r.exceptionDetails.exception || {}).description);
    return r.result.value;
  }
}

const COLLECT = (rootSel, deep, scale) => `(() => {
  const cands = ${JSON.stringify(rootSel)} === 'auto'
    ? ['[data-obs-root]', '#nice', '.markdown-preview-sizer', '.cm-content', 'body']
    : [${JSON.stringify(rootSel)}];
  let root = null;
  for (const sel of cands) {
    const el = document.querySelector(sel);
    if (el && el.children.length >= 2) { root = el; break; }
  }
  if (!root) root = document.querySelector(cands[cands.length - 1]) || document.body;
  const rootSelUsed = root.id ? '#' + root.id : ('.' + ('' + root.className).split(' ').join('.')).replace(/\\.\\./g, '.');
  const pick = (e, kind) => {
    const r = e.getBoundingClientRect();
    const s = getComputedStyle(e);
    return {
      kind: kind,
      tag: e.tagName.toLowerCase(),
      cls: ('' + (e.className || '')).slice(0, 60),
      text: (e.textContent || '').trim().replace(/\\s+/g, ' ').slice(0, 50),
      x: +r.x.toFixed(2), y: +r.y.toFixed(2),
      w: +r.width.toFixed(2), h: +r.height.toFixed(2),
      fontSize: parseFloat(s.fontSize),
      fontWeight: s.fontWeight,
      lineHeight: s.lineHeight,
      fontFamily: s.fontFamily.slice(0, 80),
      color: s.color,
      bg: s.backgroundColor,
      marginTop: parseFloat(s.marginTop),
      marginBottom: parseFloat(s.marginBottom),
      paddingTop: parseFloat(s.paddingTop),
      paddingBottom: parseFloat(s.paddingBottom),
      paddingLeft: parseFloat(s.paddingLeft),
      borderTop: parseFloat(s.borderTopWidth),
      borderLeft: parseFloat(s.borderLeftWidth),
      display: s.display
    };
  };
  const blocks = [...root.children].filter(e => e.getBoundingClientRect().height > 0 || e.tagName === 'HR').map(e => pick(e, 'block'));
  if (${deep ? 'true' : 'false'}) {
    for (const sel of ['li', 'tr', 'th', 'td', 'pre', 'blockquote p', 'h1,h2,h3,h4,h5,h6']) {
      root.querySelectorAll(sel).forEach(e => {
        const isBlock = [...root.children].includes(e);
        if (!isBlock) blocks.push(pick(e, 'sub'));
      });
    }
    blocks.sort((a, b) => (a.y - b.y) || (a.x - b.x));
  }
  const bodyStyle = getComputedStyle(document.body);
  const bottom = blocks.reduce((m, b) => Math.max(m, b.y + b.h), 0);
  return {
    blocks,
    root: rootSelUsed,
    doc: { w: document.documentElement.scrollWidth, h: document.documentElement.scrollHeight, contentBottom: Math.ceil(bottom), scale: ${scale} },
    probe: {
      webkitFontSmoothing: bodyStyle.webkitFontSmoothing,
      textRendering: bodyStyle.textRendering,
      bodyFont: bodyStyle.fontFamily.slice(0, 100),
      bodyFontSize: bodyStyle.fontSize,
      bodyWeight: bodyStyle.fontWeight
    }
  };
})()`;

async function attach(port) {
  const list = await (await fetch(`http://127.0.0.1:${port}/json/list`)).json();
  const page = list.find((t) => t.type === 'page');
  if (!page) throw new Error('no page target');
  const ws = new WebSocket(page.webSocketDebuggerUrl);
  await new Promise((res, rej) => {
    ws.addEventListener('open', res, { once: true });
    ws.addEventListener('error', rej, { once: true });
  });
  return new CDP(ws);
}

async function run(opts) {
  const {
    url,
    out,
    shot = null,
    width = 760,
    height = 900,
    scale = 2,
    rootsel = 'auto',
    deep = false,
    probe = false,
    launch = false,
    js = null,
    port = null,
    chrome = null,
  } = opts;

  let child = null;
  let usedPort = port || Number(process.env.CDP_PORT || 0);

  if (launch) {
    usedPort = port || (await freePort());
    const profile = fs.mkdtempSync(path.join(os.tmpdir(), 'obs-chrome-'));
    const args = [
      '--headless=new',
      `--remote-debugging-port=${usedPort}`,
      `--user-data-dir=${profile}`,
      '--no-sandbox',
      '--disable-gpu',
      '--disable-dev-shm-usage',
      '--allow-file-access-from-files',
      '--hide-scrollbars',
      '--force-color-profile=srgb',
      '--font-render-hinting=none',
      'about:blank',
    ];
    child = spawn(chrome || findChrome(), args, { stdio: 'ignore', detached: true });
    await waitJson(usedPort);
  } else if (!usedPort) {
    throw new Error('Pass --launch, or --port / CDP_PORT for an existing Chrome.');
  }

  let cdp;
  try {
    cdp = await attach(usedPort);
    await cdp.send('Page.enable');
    await cdp.send('Runtime.enable');
    await cdp.send('DOM.enable');
    await cdp.send('CSS.enable');
    await cdp.send('Emulation.setDeviceMetricsOverride', {
      width,
      height,
      deviceScaleFactor: scale,
      mobile: false,
    });

    if (url.startsWith('/')) url = 'file://' + url;
    await cdp.send('Page.navigate', { url });
    await sleep(300);
    // wait for loads + webfonts + one paint
    for (let i = 0; i < 60; i++) {
      const ok = await cdp.eval(
        `document.readyState === 'complete' && (document.fonts ? document.fonts.status === 'loaded' : true)`
      );
      if (ok) break;
      await sleep(100);
    }
    await cdp.eval('new Promise(r => requestAnimationFrame(() => requestAnimationFrame(r)))');
    await sleep(120);

    if (js) {
      const out = await cdp.eval(`(() => { try { return JSON.stringify(${js}); } catch (e) { return 'ERR ' + e.message; } })()`);
      console.log(out);
      return null;
    }

    if (js) {
      const out = await cdp.eval(`(() => { try { return JSON.stringify(${js}); } catch (e) { return 'ERR ' + e.message; } })()`);
      console.log(out);
      return null;
    }

    const data = await cdp.eval(COLLECT(rootsel, deep, scale));
    if (data.error) throw new Error(data.error);
    // font faces actually used, if asked
    if (probe) {
      try {
        const doc = await cdp.send('DOM.getDocument', { depth: -1 });
        const fonts = [];
        for (const b of data.blocks.slice(0, 40)) {
          if (!b.text) continue;
          const q = await cdp.send('DOM.querySelector', {
            nodeId: doc.root.nodeId,
            selector: b.tag + (b.cls ? '.' + b.cls.split(' ')[0] : ''),
          });
          if (!q || !q.nodeId) continue;
          const f = await cdp.send('CSS.getPlatformFontsForNode', { nodeId: q.nodeId });
          fonts.push({ tag: b.tag, text: b.text.slice(0, 20), fonts: f.fonts });
        }
        data.platformFonts = fonts;
      } catch (e) {
        data.platformFontsError = String(e.message || e);
      }
    }

    fs.writeFileSync(out, JSON.stringify(data, null, 1));

    if (shot) {
      // clip beyond viewport is unreliable in headless software mode: grow the
      // viewport to the content height and capture the viewport instead.
      const need = Math.min((data.doc.contentBottom || 0) + 40, 20000);
      await cdp.send('Emulation.setDeviceMetricsOverride', {
        width,
        height: Math.max(height, Math.ceil(need)),
        deviceScaleFactor: scale,
        mobile: false,
      });
      await cdp.eval('new Promise(r => requestAnimationFrame(() => requestAnimationFrame(r)))');
      await sleep(120);
      const res = await cdp.send('Page.captureScreenshot', { format: 'png' });
      fs.writeFileSync(shot, Buffer.from(res.data, 'base64'));
    }
    return data;
  } finally {
    try {
      if (child && child.pid) process.kill(-child.pid, 'SIGKILL');
    } catch (_) {
      try { child && child.kill('SIGKILL'); } catch (_) {}
    }
  }
}

function parseArgv(argv) {
  const o = { deep: false, probe: false, launch: false };
  o.url = argv[0];
  for (let i = 1; i < argv.length; i++) {
    const a = argv[i];
    const next = () => argv[++i];
    if (a === '--out') o.out = next();
    else if (a === '--shot') o.shot = next();
    else if (a === '--w') o.width = +next();
    else if (a === '--h') o.height = +next();
    else if (a === '--scale') o.scale = +next();
    else if (a === '--rootsel') o.rootsel = next();
    else if (a === '--port') o.port = +next();
    else if (a === '--chrome') o.chrome = next();
    else if (a === '--deep') o.deep = true;
    else if (a === '--probe') o.probe = true;
    else if (a === '--eval') o.js = next();
    else if (a === '--eval') o.js = next();
    else if (a === '--launch') o.launch = true;
  }
  return o;
}

if (require.main === module) {
  const o = parseArgv(process.argv.slice(2));
  if (o.js && o.url) {
    run(o).then(() => {}).catch((e) => { console.error('FAILED:', e.message); process.exit(1); });
    return;
  }
  if (!o.url || !o.out) {
    console.error('usage: node measure.js <url> --out geo.json [--shot p.png] [--launch] [--deep] [--probe]');
    process.exit(2);
  }
  run(o)
    .then((d) => {
      const maxW = Math.max(...d.blocks.map((b) => b.w));
      console.log(
        `blocks=${d.blocks.length} doc=${d.doc.w}x${d.doc.h} maxBlockW=${maxW} ` +
          `smooth=${d.probe.webkitFontSmoothing} font=${d.probe.bodyFont.split(',')[0]}`
      );
    })
    .catch((e) => {
      console.error('FAILED:', e.message);
      process.exit(1);
    });
}

module.exports = { run };
