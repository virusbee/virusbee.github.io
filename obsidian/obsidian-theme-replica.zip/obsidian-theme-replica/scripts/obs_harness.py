#!/usr/bin/env python3
"""Generate matched test pages for Obsidian theme replication.

Three render modes share one content source, so the reference renderer and the
Obsidian snippet can be compared block by block.

  ref : reference renderer. Injects the target site's CSS into #nice, the same
        container mdnice / WeChat style editors use.
  obs : Obsidian reading view. app.css + snippet + the real .markdown-preview-view
        node chain, so core rules and the snippet both apply with correct order.
  lp  : Obsidian live preview. Approximate: each block becomes a .cm-line with the
        HyperMD-* classes Obsidian uses. Good for headings, paragraphs, code.

Examples
--------
  python3 obs_harness.py --mode obs --snippet ./out.css --content doc.md \
      --width 670 --out /tmp/obs.html

  python3 obs_harness.py --mode ref --css /tmp/site.css --content doc.md \
      --width 670 --out /tmp/ref.html

  python3 obs_harness.py --mode obs --snippet ./out.css --content doc.md \
      --theme dark --out /tmp/obs-dark.html
"""

import argparse
import html
import pathlib
import re
import sys

# --------------------------------------------------------------------------
# tiny markdown -> html (no third-party deps)
# --------------------------------------------------------------------------

LIST_RE = re.compile(r"^(\s*)([-*+]|\d+[.)])\s+(.*)$")
FENCE_RE = re.compile(r"^\s*```")
HEAD_RE = re.compile(r"^(#{1,6})\s+(.*)$")
HR_RE = re.compile(r"^\s*(\*\s*\*\s*\*|-\s*-\s*-|___+)\s*$")
TABLE_SEP_RE = re.compile(r"^\s*\|?[\s:|-]+\|?\s*$")


def inline(t: str) -> str:
    t = html.escape(t, quote=False)
    t = re.sub(r"`([^`]+)`", r"<code>\1</code>", t)
    t = re.sub(r"!\[([^\]]*)\]\(([^)\s]+)\)", r'<img alt="\1" src="\2">', t)
    t = re.sub(r"\[([^\]]+)\]\(([^)\s]+)\)", r'<a href="\2">\1</a>', t)
    t = re.sub(r"\*\*([^*]+)\*\*", r"<strong>\1</strong>", t)
    t = re.sub(r"(?<![*\w])\*([^*]+)\*(?!\*)", r"<em>\1</em>", t)
    t = re.sub(r"~~([^~]+)~~", r"<del>\1</del>", t)
    return t


def starts_block(line: str) -> bool:
    s = line.strip()
    return bool(
        not s
        or FENCE_RE.match(line)
        or HEAD_RE.match(s)
        or s.startswith(">")
        or LIST_RE.match(line)
        or s.startswith("|")
        or HR_RE.match(s)
    )


def collect_list(lines, i):
    items = []
    while i < len(lines):
        line = lines[i]
        m = LIST_RE.match(line)
        if m:
            items.append([len(m.group(1)), m.group(2), m.group(3)])
            i += 1
            continue
        if line.strip() and items and (len(line) - len(line.lstrip())) > items[-1][0]:
            items[-1][2] += " " + line.strip()
            i += 1
            continue
        if not line.strip() and i + 1 < len(lines) and LIST_RE.match(lines[i + 1]):
            i += 1
            continue
        break
    return items, i


def render_list(items):
    out = []
    stack = []  # (indent, tag)
    task = any(re.match(r"^\[[ xX]\]\s+", it[2]) for it in items)
    for ind, marker, text in items:
        ordered = marker[0].isdigit()
        tag = "ol" if ordered else "ul"
        while stack and ind < stack[-1][0]:
            out.append("</li></%s>" % stack[-1][1])
            stack.pop()
        if not stack:
            cls = ' class="contains-task-list"' if task and tag == "ul" else ""
            start = ""
            if ordered:
                num = int(re.match(r"\d+", marker).group(0))
                if num != 1:
                    start = ' start="%d"' % num
            out.append("<%s%s%s>" % (tag, start, cls))
            stack.append((ind, tag))
            out.append("<li>")
        elif ind == stack[-1][0]:
            if stack[-1][1] != tag:
                out.append("</li></%s>" % stack[-1][1])
                stack.pop()
                out.append("<%s>" % tag)
                stack.append((ind, tag))
                out.append("<li>")
            else:
                out.append("</li><li>")
        else:
            out.append("<%s>" % tag)
            stack.append((ind, tag))
            out.append("<li>")
        mt = re.match(r"^\[([ xX])\]\s+(.*)$", text)
        if mt and task:
            check = " checked" if mt.group(1).lower() == "x" else ""
            out.append(
                '<input type="checkbox" class="task-list-item-checkbox" disabled%s> ' % check
            )
            out.append(inline(mt.group(2)))
        else:
            out.append(inline(text))
    while stack:
        out.append("</li></%s>" % stack[-1][1])
        stack.pop()
    return "".join(out)


def render_table(lines, i):
    rows = []
    while i < len(lines) and lines[i].strip().startswith("|"):
        rows.append(lines[i].strip())
        i += 1
    def cells(row):
        row = row.strip()
        if row.startswith("|"):
            row = row[1:]
        if row.endswith("|"):
            row = row[:-1]
        return [c.strip() for c in row.split("|")]
    align = []
    for c in cells(rows[1]):
        left, right = c.startswith(":"), c.endswith(":")
        align.append("center" if left and right else "right" if right else "left" if left else "")
    head = cells(rows[0])
    body = rows[2:]
    def td(tag, text, idx):
        a = align[idx] if idx < len(align) else ""
        style = ' style="text-align:%s"' % a if a else ""
        return "<%s%s>%s</%s>" % (tag, style, inline(text), tag)
    out = ["<table>", "<thead><tr>"]
    out += [td("th", t, k) for k, t in enumerate(head)]
    out.append("</tr></thead><tbody>")
    for r in body:
        cs = cells(r)
        out.append("<tr>" + "".join(td("td", t, k) for k, t in enumerate(cs)) + "</tr>")
    out.append("</tbody></table>")
    return "".join(out), i


def parse_md(md: str) -> str:
    lines = md.splitlines()
    n = len(lines)
    i = 0
    if n >= 3 and lines[0].strip() == "---":
        for j in range(1, n):
            if lines[j].strip() in ("---", "..."):
                i = j + 1
                break
    out = []
    while i < n:
        line = lines[i]
        s = line.strip()
        if not s:
            i += 1
            continue
        if FENCE_RE.match(line):
            lang = s[3:].strip()
            i += 1
            buf = []
            while i < n and not FENCE_RE.match(lines[i]):
                buf.append(lines[i])
                i += 1
            i += 1
            cls = ' class="language-%s"' % lang if lang else ""
            out.append("<pre><code%s>%s</code></pre>" % (cls, html.escape("\n".join(buf))))
            continue
        m = HEAD_RE.match(s)
        if m:
            lvl = len(m.group(1))
            out.append("<h%d>%s</h%d>" % (lvl, inline(m.group(2)), lvl))
            i += 1
            continue
        if s.startswith(">"):
            buf = []
            while i < n and lines[i].strip().startswith(">"):
                buf.append(re.sub(r"^\s*>\s?", "", lines[i]))
                i += 1
            out.append("<blockquote>%s</blockquote>" % parse_md("\n".join(buf)))
            continue
        if LIST_RE.match(line):
            items, i = collect_list(lines, i)
            out.append(render_list(items))
            continue
        if s.startswith("|") and i + 1 < n and TABLE_SEP_RE.match(lines[i + 1]) and "-" in lines[i + 1]:
            tbl, i = render_table(lines, i)
            out.append(tbl)
            continue
        if HR_RE.match(s):
            out.append("<hr>")
            i += 1
            continue
        buf = [s]
        i += 1
        while i < n and not starts_block(lines[i]):
            buf.append(lines[i].strip())
            i += 1
        out.append("<p>%s</p>" % inline(" ".join(buf)))
    return "\n".join(out)


# --------------------------------------------------------------------------
# live preview approximation
# --------------------------------------------------------------------------

def to_lines(block_html: str) -> str:
    """Rewrite block html into .cm-line nodes with HyperMD-* classes."""
    out = []

    def repl_h(m):
        lvl, text = m.group(1), m.group(2)
        return (
            '<div class="cm-line HyperMD-header HyperMD-header-%s cm-header cm-header-%s">'
            '<span class="cm-formatting cm-formatting-header">%s </span>'
            '<span class="cm-header cm-header-%s">%s</span></div>'
            % (lvl, lvl, "#" * int(lvl), lvl, text)
        )

    block_html = re.sub(r"<h([1-6])>(.*?)</h\1>", repl_h, block_html, flags=re.S)
    block_html = re.sub(r"<p>(.*?)</p>", r'<div class="cm-line">\1</div>', block_html, flags=re.S)
    block_html = re.sub(r"<hr\s*/?>", r'<div class="cm-line HyperMD-hr"><span class="cm-hr">---</span></div>', block_html)
    block_html = re.sub(r"<pre><code([^>]*)>(.*?)</code></pre>",
                        r'<div class="cm-line HyperMD-codeblock HyperMD-codeblock-bg"><code\1>\2</code></div>',
                        block_html, flags=re.S)
    block_html = re.sub(r'<div class="cm-line">(.*?)</div>',
                        lambda m: '<div class="cm-line">%s</div>' % m.group(1), block_html, flags=re.S)
    # tables become a widget
    block_html = re.sub(r"<table>", '<div class="cm-table-widget"><table>', block_html)
    block_html = re.sub(r"</table>", "</table></div>", block_html)
    # lists: wrap whole list in one block, items become list lines
    block_html = re.sub(r"<li>", '<div class="cm-line HyperMD-list-line HyperMD-list-line-1">', block_html)
    block_html = re.sub(r"</li>", "</div>", block_html)
    block_html = re.sub(r"<(ol|ul)[^>]*>", '<div class="HyperMD-list-line-wrap">', block_html)
    block_html = re.sub(r"</(ol|ul)>", "</div>", block_html)
    block_html = re.sub(r"</?(blockquote|strong|em|code|a|img|input|del|span|thead|tbody|tr|th|td)[^>]*>",
                        lambda m: m.group(0), block_html)
    out.append(block_html)
    return "".join(out)


# --------------------------------------------------------------------------
# page shells
# --------------------------------------------------------------------------

OBS_DOM = (
    '<div class="app-container"><div class="horizontal-main-container">'
    '<div class="workspace"><div class="workspace-leaf"><div class="workspace-leaf-content">'
    '<div class="view-content"><div class="markdown-reading-view">'
    '<div class="markdown-preview-view markdown-rendered">'
    '<div class="markdown-preview-sizer markdown-preview-section">{body}</div>'
    "</div></div></div></div></div></div></div></div>"
)

LP_DOM = (
    '<div class="app-container"><div class="horizontal-main-container">'
    '<div class="workspace"><div class="workspace-leaf"><div class="workspace-leaf-content">'
    '<div class="view-content"><div class="markdown-source-view mod-cm6">'
    '<div class="cm-editor"><div class="cm-scroller"><div class="cm-content">{body}</div></div></div>'
    "</div></div></div></div></div></div></div>"
)


def _wrap_li_sections(body: str) -> str:
    """mdnice 的每条 li 都把文字包在 <section> 里（嵌套列表时 section 只包本层文字）。

    很多主题的 li 行高、条目间距都写在 `li section` 上，不还原这层包裹，
    参照页的列表会整体矮一截，比对结果全是假阴/假阳。
    """
    inner = re.compile(r"<li>(?!<section>)((?:(?!<ul[ >]|<ol[ >]|</li>)[\s\S])*)</li>")
    while True:
        new = inner.sub(lambda m: "<li><section>%s</section></li>" % m.group(1), body)
        if new == body:
            break
        body = new
    # 带子列表的 li：只把开头那段文字包起来，子列表留在 section 外面
    lead = re.compile(
        r"<li>(?!<section>)([^<]*(?:<(?!ul[ >]|ol[ >]|/li)[^>]*>[^<]*)*)(?=<(?:ul|ol)[ >])"
    )
    return lead.sub(
        lambda m: "<li><section>%s</section>" % m.group(1) if m.group(1).strip() else "<li>",
        body,
    )


def _pre_block(m) -> str:
    lines = m.group(1).split("\n")
    inner = "<br>".join("<span>%s</span>" % (ln if ln.strip() else "&nbsp;") for ln in lines)
    return '<pre class="custom"><code class="hljs">%s<br></code></pre>' % inner


def _preset_mdnice(body: str) -> str:
    # 标题文字在 span.content 里，字号规则挂在 .content 上
    body = re.sub(
        r"<h([1-6])>(.*?)</h\1>",
        lambda m: '<h%s><span class="prefix"></span><span class="content">%s</span>'
        '<span class="suffix"></span></h%s>' % (m.group(1), m.group(2), m.group(1)),
        body,
        flags=re.S,
    )
    # 表格规则的选择器是 `#nice .table-container table ...`，没有这层容器一条都不命中
    body = re.sub(
        r"(<table[\s\S]*?</table>)", r'<div class="table-container">\1</div>', body
    )
    # 代码块真实结构：<pre class="custom"><code class="hljs">行<br>…</code></pre>
    # 行高 26px 写在 `pre.custom code span` 上，不拆成 span 就退回 1.5 倍行高
    body = re.sub(r"<pre><code[^>]*>([\s\S]*?)</code></pre>", _pre_block, body)
    body = re.sub(r"<blockquote>", '<blockquote class="custom-blockquote">', body)
    return _wrap_li_sections(body)


PRESETS = {
    "mdnice": _preset_mdnice,
    "none": lambda b: b,
}


def build(args) -> str:
    md = pathlib.Path(args.content).read_text(encoding="utf-8")
    body = parse_md(md)
    if args.mode == "ref":
        body = PRESETS.get(args.preset, PRESETS["none"])(body)
    if args.mode == "lp":
        body = to_lines(body)
        shell = LP_DOM.replace("{body}", body)
    elif args.mode == "obs":
        shell = OBS_DOM.replace("{body}", body)
    else:
        shell = '<div id="nice">{body}</div>'.replace("{body}", body)

    css_blocks = []
    if args.mode == "ref":
        for p in args.css or []:
            css_blocks.append(pathlib.Path(p).read_text(encoding="utf-8"))
    else:
        if args.app_css:
            css_blocks.append(pathlib.Path(args.app_css).read_text(encoding="utf-8"))
        if args.snippet:
            css_blocks.append(pathlib.Path(args.snippet).read_text(encoding="utf-8"))

    width = args.width
    # Do NOT touch the shell (.app-container / .workspace): app.css lays it out with
    # height:100vh + paint containment, and overriding it collapses the 0-height box
    # and clips every pixel away while geometry still reads fine. Instead the
    # measurement step grows the viewport to the content height, so 100vh == content.
    fit = ""
    if args.mode == "obs":
        fit = (
            ".markdown-preview-view{--file-line-width:%dpx}"
            ".markdown-preview-sizer{padding:0!important;margin:0!important;"
            "max-width:%dpx!important;width:%dpx!important}"
            % (width, width, width)
        )
    elif args.mode == "lp":
        fit = (
            ".cm-scroller{overflow:visible!important;padding:0!important}"
            ".cm-content{width:%dpx!important;max-width:%dpx!important;padding:0!important}"
            "body{--file-line-width:%dpx}" % (width, width, width)
        )
    else:
        # content-box so #nice's own horizontal padding does not shrink the text column
        fit = ".ref,#nice{width:%dpx;box-sizing:content-box}" % width

    theme = "theme-dark" if args.theme == "dark" else "theme-light"
    extra = pathlib.Path(args.extra_css).read_text(encoding="utf-8") if args.extra_css else ""
    bg = "#1e1e1e" if args.theme == "dark" else "#ffffff"

    return (
        "<!DOCTYPE html><html><head><meta charset=\"utf-8\">"
        "<style>html,body{margin:0;padding:0;background:%s}</style>" % bg
        + "".join("<style>%s</style>" % c for c in css_blocks)
        + "<style>%s\n%s\n%s</style>" % (fit, args.css_extra or "", extra)
        + '</head><body class="%s">' % theme
        + shell
        + "</body></html>"
    )


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--mode", choices=["ref", "obs", "lp"], default="obs")
    ap.add_argument("--content", required=True, help="markdown file")
    ap.add_argument("--out", required=True, help="html output path")
    ap.add_argument("--css", action="append", help="reference CSS (mode=ref, repeatable)")
    ap.add_argument("--snippet", help="Obsidian snippet CSS to test")
    ap.add_argument("--app-css", default=None, help="Obsidian app.css for mode=obs/lp")
    ap.add_argument("--width", type=int, default=670)
    ap.add_argument("--theme", choices=["light", "dark"], default="light")
    ap.add_argument("--preset", choices=sorted(PRESETS), default="none",
                    help="reference DOM wrapper preset (mdnice wraps heading text in span.content)")
    ap.add_argument("--extra-css", default=None, help="extra stylesheet appended last")
    ap.add_argument("--css-extra", default="", help="inline CSS appended last")
    ap.add_argument("--print", action="store_true", help="print html instead of writing")
    args = ap.parse_args()

    doc = build(args)
    if args.print:
        sys.stdout.write(doc)
    else:
        pathlib.Path(args.out).write_text(doc, encoding="utf-8")
        print("wrote %s (%d bytes)" % (args.out, len(doc)))


if __name__ == "__main__":
    main()
