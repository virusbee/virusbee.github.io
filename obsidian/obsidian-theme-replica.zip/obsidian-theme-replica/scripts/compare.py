#!/usr/bin/env python3
"""Compare two measured pages block by block.

Input: two JSON files produced by measure.js (reference vs Obsidian).

  python3 compare.py ref.json obs.json
  python3 compare.py ref.json obs.json --tol 0.6 --md report.md
  python3 compare.py ref.json obs.json --ink --shot-ref r.png --shot-obs o.png
  python3 compare.py ref.json obs.json --img compare.png --shot-ref r.png --shot-obs o.png

Exit code is 0 when every matched block is within --tol (after removing the
global offset), 1 otherwise. That makes it usable as a gate in a loop.
"""

import argparse
import json
import re
import sys


def norm(t):
    return re.sub(r"\s+", " ", (t or "")).strip()


def load(p):
    with open(p, encoding="utf-8") as f:
        return json.load(f)


def align(ref, obs):
    """Return list of (ref_block, obs_block). Text first, index as fallback."""
    pairs = []
    if len(ref) == len(obs):
        same = sum(1 for a, b in zip(ref, obs) if norm(a["text"])[:12] == norm(b["text"])[:12])
        if same >= len(ref) * 0.7:
            return list(zip(ref, obs))
    j = 0
    for a in ref:
        key = norm(a["text"])[:16]
        hit = None
        for k in range(j, min(len(obs), j + 6)):
            if norm(obs[k]["text"])[:16] == key and obs[k]["tag"] == a["tag"]:
                hit = k
                break
        if hit is None:
            for k in range(j, min(len(obs), j + 6)):
                if norm(obs[k]["text"])[:16] == key:
                    hit = k
                    break
        if hit is None:
            pairs.append((a, None))
        else:
            pairs.append((a, obs[hit]))
            j = hit + 1
    return pairs


def ink_of(img, box, scale, thr=170):
    from PIL import Image

    x, y, w, h = [int(round(v * scale)) for v in box]
    if w <= 0 or h <= 0:
        return 0, 0.0
    c = img.crop((x, y, x + w, y + h)).convert("L")
    px = c.load()
    W, H = c.size
    n = 0
    dark = 0
    for yy in range(H):
        for xx in range(W):
            v = px[xx, yy]
            if v < thr:
                n += 1
            dark += 255 - v
    return n, dark / 1000.0


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("ref")
    ap.add_argument("obs")
    ap.add_argument("--tol", type=float, default=0.6, help="allowed |dy| in px")
    ap.add_argument("--offset", default="auto", help="auto | 0 | number")
    ap.add_argument("--md", help="write the table to this markdown file")
    ap.add_argument("--ink", action="store_true", help="compare ink per block")
    ap.add_argument("--shot-ref")
    ap.add_argument("--shot-obs")
    ap.add_argument("--scale", type=float, default=None, help="screenshot px per CSS px (default: from json)")
    ap.add_argument("--img", help="write a stacked comparison image here")
    ap.add_argument("--max-rows", type=int, default=60)
    args = ap.parse_args()

    R, O = load(args.ref), load(args.obs)
    scale = args.scale or (R.get("doc", {}).get("scale") or 2.0)
    scale = args.scale or (R.get("doc", {}).get("scale") or 2.0)
    pairs = align(R["blocks"], O["blocks"])

    matched = [(a, b) for a, b in pairs if b]
    if not matched:
        print("no block matched: check --rootsel and content")
        return 1

    if args.offset == "auto":
        off = matched[0][1]["y"] - matched[0][0]["y"]
    elif args.offset == "0":
        off = 0.0
    else:
        off = float(args.offset)

    rows = []
    worst = ("", 0.0)
    over = 0
    for i, (a, b) in enumerate(pairs, 1):
        if not b:
            rows.append((i, a["tag"], norm(a["text"])[:26], a["y"], None, None, None, None, "MISSING"))
            over += 1
            continue
        dy = round(b["y"] - off - a["y"], 2)
        dh = round(b["h"] - a["h"], 2)
        flag = "" if abs(dy) <= args.tol else "DY"
        if abs(dh) > args.tol:
            flag += "DH"
        if flag:
            over += 1
        if abs(dy) > abs(worst[1]):
            worst = (norm(a["text"])[:16] or a["tag"], dy)
        rows.append((i, a["tag"], norm(a["text"])[:26], a["y"], b["y"] - off, dy, a["h"], b["h"], flag))

    lines = []
    lines.append("| # | tag | text | ref y | obs y | dy | ref h | obs h | flag |")
    lines.append("|---|---|---|---|---|---|---|---|---|")
    for r in rows[: args.max_rows]:
        i, tag, txt, ry, oy, dy, rh, oh, flag = r
        lines.append(
            "| %s | %s | %s | %s | %s | %s | %s | %s | %s |"
            % (
                i,
                tag,
                txt.replace("|", "\\|"),
                ry,
                "-" if oy is None else round(oy, 2),
                "-" if dy is None else dy,
                rh,
                "-" if oh is None else oh,
                flag,
            )
        )

    head = [
        "offset used: %.2f px (%s)" % (off, args.offset),
        "blocks: %d matched, %d unmatched" % (len(matched), len(pairs) - len(matched)),
        "worst dy: %.2f px at %r" % (worst[1], worst[0]),
        "clean: %d / %d" % (len(pairs) - over, len(pairs)),
    ]
    print("\n".join(head))
    print("\n".join(lines))

    if args.ink and args.shot_ref and args.shot_obs:
        from PIL import Image

        ri, oi = Image.open(args.shot_ref), Image.open(args.shot_obs)
        # ink is only meaningful for text blocks; code/table backgrounds dominate otherwise
        INK_TAGS = {"h1", "h2", "h3", "h4", "h5", "h6", "p", "li", "td", "th", "blockquote"}
        print("\nink (ref -> obs), text blocks only:")
        total_r = total_o = 0.0
        for a, b in matched[: args.max_rows]:
            if not a["text"] or a["tag"] not in INK_TAGS:
                continue
            # each side is cropped in its own coordinate space: dy drift must not leak in
            nr, dr = ink_of(ri, (a["x"], a["y"], a["w"], a["h"]), scale)
            no, do = ink_of(oi, (b["x"], b["y"], b["w"], b["h"]), scale)
            total_r += dr
            total_o += do
            if dr > 1:
                print(
                    "  %-10s %-22s dark %8.1f -> %8.1f  (%+.1f%%)  px %6d -> %6d"
                    % (a["tag"], norm(a["text"])[:22], dr, do, (do - dr) / dr * 100, nr, no)
                )
        if total_r > 0:
            print("  TOTAL dark %.1f -> %.1f  (%+.1f%%)" % (total_r, total_o, (total_o - total_r) / total_r * 100))

    if args.img and args.shot_ref and args.shot_obs:
        from PIL import Image, ImageDraw

        a = Image.open(args.shot_ref).convert("RGB")
        b = Image.open(args.shot_obs).convert("RGB")
        W = max(a.size[0], b.size[0])
        canvas = Image.new("RGB", (W, a.size[1] + b.size[1] + 64), "white")
        d = ImageDraw.Draw(canvas)
        canvas.paste(a, (0, 26))
        canvas.paste(b, (0, a.size[1] + 56))
        d.text((8, 8), "REFERENCE  %s" % args.shot_ref, fill=(90, 90, 90))
        d.text((8, a.size[1] + 38), "OBSIDIAN  %s" % args.shot_obs, fill=(90, 90, 90))
        canvas.save(args.img)
        print("image: %s (%dx%d)" % (args.img, canvas.size[0], canvas.size[1]))

    if args.md:
        with open(args.md, "w", encoding="utf-8") as f:
            f.write("# geometry diff\n\n" + "\n".join(["* " + h for h in head]) + "\n\n")
            f.write("\n".join(lines) + "\n")

    return 0 if over == 0 else 1


if __name__ == "__main__":
    sys.exit(main())
