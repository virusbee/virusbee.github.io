# 一级标题 Heading 1

这是正文段落，用来对照字号、行高、段距与字重。正文里混排英文 words like Obsidian、数字 16px 与标点，检查中英文基线是否对齐。

第二段紧接着上一段，中间不空行也会有段间距。行内代码写作 `--file-line-width`，加粗写作 **重点内容**，斜体写作 *强调*，链接写作 [Obsidian](https://obsidian.md)。

## 二级标题 Heading 2

### 三级标题 Heading 3

#### 四级标题 Heading 4

##### 五级标题 Heading 5

###### 六级标题 Heading 6

## 列表

无序列表三级嵌套，用来检测缩进与符号形状：

- 第一级条目 A
- 第一级条目 B
  - 第二级条目 B1
  - 第二级条目 B2
    - 第三级条目 B2a
- 第一级条目 C

有序列表：

1. 第一步，取参照样式
2. 第二步，建立参考页
3. 第三步，逐块比对

任务清单：

- [ ] 未完成的条目
- [x] 已完成的条目

## 引用

> 引用第一行，检查左边框的粗细、颜色与内边距。
>
> 引用第二段，检查段间距是否被压缩。

## 表格

| Key | Description | Value |
| --- | --- | --- |
| platform | 测试运行的平台 | iOS Simulator, tvOS Simulator |
| name | 测试使用的模拟器全称 | Xcode 设备管理器中显示的名称 |
| id | 测试使用的模拟器 ID | 同上 |

## 代码

行内代码与代码块要分别验证，因为两者的字体、字号、背景常常不一致。

```css
.markdown-rendered pre {
  border-radius: 5px;
  background: #282c34;
  padding: 15px 16px 16px;
}
```

## 分隔线与其他

---

图片段落（无图时留空，检查上下间距）：

最后一段，用来确认文末没有多余的外边距。
