---
name: obsidian-theme-replica
description: This skill should be used when replicating a web page's or editor's markdown rendering (Feishu docs, Typora, mdnice, Notion, GitHub, VS Code, any site with rendered long-form text) into an Obsidian CSS snippet, or when an existing snippet "looks off" and needs pixel-level alignment. It covers style extraction from local CSS files or a logged-in site, block-by-block geometry and ink comparison through headless Chrome, the Obsidian core override traps that break snippets, and light/dark delivery.
agent_created: true
---

# Obsidian 主题复刻

把任意渲染器的 markdown 样式，复刻成 Obsidian 可用的 CSS snippet。目标不是"看着像"，是**逐块坐标对齐**：标题、段落、列表、引用、表格、代码块在同一份内容下，y 坐标与块高与参照页一致，误差控制在 0.6px 内。

复刻的难点从来不在写 CSS，在两件事：拿到真实的参照样式（而不是设计规范或猜测），以及知道 Obsidian 核心在哪一层把样式吃掉了。本 skill 用三个脚本把这两件事变成可重复的流程。

## 交付物

一个 `.css` 文件，放进 `<vault>/.obsidian/snippets/`，在设置里启用。文件内部结构固定：

1. 头部注释：来源、版本、日期、关键实测值
2. 变量区：颜色 / 字号 / 间距 / 字体栈，全部收在 `body, body.theme-dark, body.theme-light` 上
3. 阅读视图规则，作用域 `.markdown-rendered`
4. 实时预览规则，作用域 `.markdown-source-view.mod-cm6`
5. 暗色覆盖，只换色不改布局

## 开工前先锁定五件事

缺任何一项都会在后面变成返工。信息不全时一次性问清，只问一轮：

| 项 | 要拿到什么 | 缺失的后果 |
|---|---|---|
| 参照物 | 可访问的页面 URL / 本地 CSS 文件 / 截图 | 只能靠设计规范猜，整版返工 |
| 环境 | Obsidian 版本、是否装了社区主题、亮暗是否都要、版心宽度 | 变量被覆盖、缩进叠加，全部算错 |
| 验收 | 逐块坐标对齐，还是目检像即可 | 用 0.6px 的标准做"像就行"的活，成本差一个量级 |
| 边界 | 哪些必须 1:1，哪些可以取舍（例如参照页的双线表格在 Obsidian 里很难看） | 交付一个几何全对、视觉全错的产物 |
| 卡点 | 需要登录 / 扫码 / 本地安装的环节 | 中途卡住，整轮重来 |

参照页面的渲染宽度要单独确认。375 / 670 / 914 是三种完全不同的排版结果。

## 流程

### Step 1 取参照样式

三条路径，按可得性选：

- **本地 CSS**（Typora、VS Code 这类）：直接读安装目录里的主题文件，通常主文件 + `base.css` 两层。
- **公开页面**：起一个带调试端口的 Chrome，滚到目标位置，`getComputedStyle` 逐块取。
- **需要登录的编辑器**（mdnice、公众号排版器）：先让用户登录，再操作 UI 切到目标主题，最后用 CDP `CSS.getMatchedStylesForNode` 反查命中的样式表。这类站点的主题常常是 CSSOM 注入的，`document.styleSheets` 读不到。

细节与代码见 `references/extraction.md`。

**必须检查 body 级规则**。页面级 `-webkit-font-smoothing: antialiased` 会让笔画细 12%–15%，它通常不在主题作用域里，导入组件 CSS 时会漏掉，是"字重不对"最常见的原因。

### Step 2 建参照页并目检

```bash
python3 scripts/obs_harness.py --mode ref --css <site.css> \
    --content assets/sample-content.md --width 670 --preset mdnice --out /tmp/ref.html
```

`assets/sample-content.md` 覆盖六级标题、嵌套列表、任务清单、引用、表格、行内代码、代码块、分隔线。用它当基准内容，四套主题之间也能互相比较。

两条硬性要求：

1. **参照页的 DOM 结构必须与目标站点一致**。目标站点的 CSS 选择器往往挂在内层包裹元素上，少一层包裹，整批规则就不命中，而且不会报错，只会静默退化成浏览器默认样式。`--preset mdnice` 还原了四层结构：标题文字包 `<span class="content">`、列表项包 `<section>`、表格包 `.table-container`、代码块 `pre.custom`。换别的站点时，先看导出 HTML 的真实嵌套，再改 `PRESETS`。

   这个坑非常隐蔽：mdnice 的 `li` 行高和条目间距全写在 `li section` 上，不包 `section` 时参照页每条列表矮 4.8px，逐块比对会报出一串 187px 的累积漂移，看起来像 snippet 写错了，实际是参照页错了。

2. **先截图目检，再相信 diff**。参照页里出现「所有列表项都是 24px」「表头只有 26px」这种整数默认值，说明注入的 CSS 没命中，此时任何 diff 都不可信。参照页能和真实页面截图对上，才拿它当基准。

### Step 3 建 Obsidian 页

```bash
python3 scripts/obs_harness.py --mode obs \
    --app-css /tmp/obsidian-css/app.css --snippet ./out.css \
    --content assets/sample-content.md --width 670 --out /tmp/obs.html
```

必须注入 `app.css`。Obsidian 核心的 `li { margin-inline-start: 3ch }`、`--list-spacing`、`--p-spacing` 会和 snippet 叠加，只注入 snippet 得到的是假象。

`app.css` 从本机 Obsidian 安装包资源里取，或由用户提供，不要用其他渲染结果替代。

### Step 4 量测

```bash
node scripts/measure.js file:///tmp/ref.html --out /tmp/ref.json \
    --shot /tmp/ref.png --launch --deep --probe --w 760
node scripts/measure.js file:///tmp/obs.html --out /tmp/obs.json \
    --shot /tmp/obs.png --launch --deep --w 760
```

`--deep` 额外采集 `li / tr / th / td / pre`，表格与列表的偏差藏在这些子元素里。`--probe` 输出平台字体命中与 body 级渲染设置，用于排查字体问题。

截图是整页的，视口自动长到内容高度，像素比 2，坐标为 CSS px，实际倍率记录在 `doc.scale`。

### Step 5 比对并修正

```bash
python3 scripts/compare.py /tmp/ref.json /tmp/obs.json --tol 0.6 \
    --ink --shot-ref /tmp/ref.png --shot-obs /tmp/obs.png --img /tmp/cmp.png
```

输出四行摘要（offset、匹配数、最大 Δy、clean 比例）与逐块表。`--offset auto` 扣掉首块的整体偏移（Obsidian 顶栏通常带来 20–44px 差异），之后每一块都必须为 0。

修正顺序固定，先粗后细：

1. 字号 / 行高 / 字重（错一个，全篇漂移）
2. 块级 margin 与 padding（决定 Δy 的累积）
3. 水平尺寸（版心、单元格 padding、列表缩进）
4. 颜色、边框、圆角、背景

`--ink` 给出文本块的墨量比，用于判断字重与抗锯齿是否一致，正常波动 ±5%。它只对文字块有意义，代码块和表格的深色背景会盖过文字。

### Step 6 实时预览

阅读视图对齐后再补实时预览，两者是两套选择器：

```bash
python3 scripts/obs_harness.py --mode lp --app-css ... --snippet ./out.css \
    --content assets/sample-content.md --width 670 --out /tmp/lp.html
```

`lp` 模式是近似实现：每个块转成 `.cm-line` 加对应 `HyperMD-*` 类。标题字号走 `--h*-size`，代码块背景由 `HyperMD-codeblock-bg` 这层绘制，表格在 `.cm-table-widget` 里的 `table`。改动必须同时落在两套选择器上，否则会出现"阅读视图对了、编辑视图没变"。

### Step 7 明暗双验与交付

```bash
python3 scripts/obs_harness.py --mode obs --snippet ./out.css --theme dark ...
```

暗色必须重新量一遍，不能只换颜色不验布局。交付前跑一遍清单：

- [ ] `--tol 0.6` 下 clean 比例 100%，或所有偏差都有书面解释
- [ ] 明 / 暗两套截图目检：文字可读、边框可见、斑马纹不断裂
- [ ] 变量全部定义在 `body, body.theme-dark, body.theme-light` 上，防止社区主题覆盖
- [ ] 文件头写明来源、日期、关键实测值
- [ ] 375 / 670 两种版心各看一眼
- [ ] 告知用户重载方式（切换片段或 `Cmd/Ctrl+R`）

## 判断原则

**信渲染，不信规范。** 设计规范写 15px，真实页面可能是 16px。差这一号，整页呼吸感都不对。

**能读计算样式就别用肉眼。** 3px 的圆点偏移、2.3px 的行盒差、8% 的墨量差，眼睛只能感觉"不对"，量出来才知道改哪个值。

**数据对不等于好看。** 参照页的双线表格在网页里成立，搬到 Obsidian 里就是碎盒子。几何全对时仍要目检，并在交付时把"要不要 100% 还原"作为开关留给用户。

**优先找共用变量再改数。** 一个 `--list-indent` 可能同时管无序列表、有序列表和任务清单，改一个坏两个。

## 常见陷阱

Obsidian 核心覆盖、变量优先级、行盒计算、字体落回等已知坑（含症状与修法）见 `references/obsidian-overrides.md`。动手前扫一遍，能省掉大半返工。

四套已完成主题的实测数值、参照页特征与具体坑位见 `references/cases.md`，可作为新主题的对照参考。

## 脚本

| 脚本 | 用途 | 关键参数 |
|---|---|---|
| `scripts/obs_harness.py` | 生成参照页 / 阅读视图页 / 实时预览页 | `--mode ref\|obs\|lp` `--width` `--preset` `--theme` |
| `scripts/measure.js` | CDP 量测几何与计算样式，整页截图 | `--launch` `--deep` `--probe` `--eval` |
| `scripts/compare.py` | 逐块 Δy / Δh / 墨量比对，拼对照图 | `--tol` `--offset` `--ink` `--img` |

`measure.js` 也支持连已有 Chrome：`--port 9222`，用于登录态页面。`--eval "<js>"` 可临时探查任意计算样式，不必改脚本。

依赖：Node ≥ 18（内置 WebSocket 与 fetch）、Python 3 + Pillow、本机 Chrome。脚本只用了标准库与 Chrome DevTools Protocol，没有绑定任何编辑器或平台 API：Chrome 路径按 macOS / Linux / Windows 三套默认位置探测，也可 `--chrome` 指定。

跨 agent 使用时，整个目录就是一份标准 Agent Skills 包（`SKILL.md` + `scripts/` + `references/` + `assets/`），复制到对应 agent 的 skills 目录即可；唯一要求是那个 agent 能执行 shell 命令、能拉起本地 Chrome。
